/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase05;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Operadores incrementales y decrementales
        /*
        ++ incremento en 1
        -- decremento en 1
        Son operadores unarios, trabajan con un solo operador.
        */
        
        int nro1 = 0;
        
        nro1 ++; //incrementa en 1 el valor de la variable
        //es lo mismo que: nro1 = nro1 + 1
        //es lo mismo que: nro1 += 1
        System.out.println(nro1); //de 0 pasa a valer 1
        
        nro1 --; //decrementa en 1 el valor de la variable
        System.out.println(nro1); //de 1 pasa a valer 0
        
        
        //Operadores relacionales
        /*
        >  mayor
        <  menor
        >= mayor o igual
        <= menor o igual
        == igual
        != distinto
        Son operadores binarios.
        Los operandos son num�ricos y el resultado es booleano.
        */
        
        nro1 = 15;
        int nro2 = 20;
        
        System.out.println(nro1 > nro2); //false
        System.out.println(nro1 < nro2); //true
        System.out.println(nro1 >= nro2); //false
        System.out.println(nro1 <= nro2); //true
        System.out.println(nro1 == nro2); //false
        System.out.println(nro1 != nro2); //true
        
        //Tabla de verdad
        //es una representaci�n l�gica de resultados
        /*
        X   Y   AND  OR
        V   V   V   V
        V   F   F   V
        F   V   F   V
        F   F   F   F
        
        Negaci�n (NOT)
        X   NOT
        V   F
        F   V
        */
        
        //Operadores l�gicos
        /*
        & AND (y l�gico)
        | OR (o l�gico)
        ! NOT (negaci�n)
        Los operandos son booleanos.
        El resultado es booleano.
        */
        
        boolean log1 = true;
        boolean log2 = false;
        
        /*
        Un solo operador l�gico & � | eval�a ambas condiciones.
        Al utilizar dos && o || si con una condici�n determina el valor de 
        verdad, no eval�a la condici�n que sigue.
        */
        
        System.out.print("AND && ");
        System.out.println(log1 && log2); //false
        
        System.out.print("OR || ");
        System.out.println(log1 || log2); //true
        
        System.out.println("NOT !");
        System.out.println(!log1); //false
        System.out.println(!log2); //true
        
        //Ejercicios Java
        
        /*
        Dados n1=5, n2=10 y n3=20. Informar:
        a) n1+n2
        b) n3-n1
        c) n1*n3
        d) n3/n2
        */       
        
        int n1=5, n2=10, n3=20;        
        
        int suma = n1 + n2;
        int resta = n3 - n1;
        int multiplicacion = n1 * n3;
        int division = n3 / n2;
        
        System.out.println("La suma de n1 y n2 es: " + suma);
        System.out.println("La resta de n3 y n1 es: " + resta);
        System.out.println("La multiplicaci�n de n1 y n3 es: " + multiplicacion);
        System.out.println("La divisi�n de n3 y n2 es: " + division);
        
        
        /*
        Dados n1=10, n2=20 y n3=30. Informar :
        a) El total de la suma de todas las variables
        b) El promedio
        c) El resto entre n2 y n1
        */
        
        n1 = 10;
        n2 = 20;
        n3 = 30;
        
        int sumaTotal = n1 + n2 + n3;
        int promedio = sumaTotal / 3;
        int resto = n2 % n1;
        
        System.out.println("El total de la suma de todas las variables "
                + "es: "+sumaTotal);
        System.out.println("El promedio es: "+promedio);
        System.out.println("El resto entre n2 y n1 es: "+resto);
        
        /*
        Declarar dos variables n1=5 y n2=10.
        Utilizando concatenaci�n entre las variables y los literales, 
        mostrar en pantalla la siguiente expresi�n:
        n1 es igual a 5,n2 es igual a 10 y n1 m�s n2 es igual a 15.
        */
        
        n1 = 5;
        n2 = 10;
        suma = n1 + n2;
        System.out.println("n1 es igual a "+n1+", n2 es igual a "+n2+" y "
                + "n1 m�s n2 es igual a "+suma+".");
        
        /*
        Haciendo uso de la constante IVA=21,calcular el precio con IVA 
        de los siguientes productos e informar:
        a) remera:$59.90
        b) pantal�n:$99.90
        c) campera:$149.90
        */
        
        final double IVA = 21;
        double remera = 59.90;
        double pantalon = 99.90;
        double campera = 149.90;
        
        double remeraConIva = (remera / 100) * IVA + remera;
        double pantalonConIva = (pantalon / 100) * IVA + pantalon;
        double camperaConIva = (campera / 100) * IVA + campera;
        
        System.out.println("La remera con IVA vale: "+remeraConIva);
        System.out.println("El pantal�n con IVA vale: "+pantalonConIva);
        System.out.println("La campera con IVA vale: "+camperaConIva);
        
    }
    
}
