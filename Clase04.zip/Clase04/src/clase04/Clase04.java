/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase04;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        String palabra1 = "uesta";
        String palabra2 = "subir";
        String palabra3 = "la";
        String palabra4 = "a";
        String palabra5 = "e";
        String palabra6 = "l";
        String palabra7 = "v";
        String palabra8 = "s";
        String palabra9 = "n";
        String palabra10 = "d";
        String palabra11 = "y";
        String palabra12 = "medio";
        String palabra13 = "C";
        
        //A Cuesta le cuesta subir la cuesta. Y en medio de la cuesta, va y
        //se acuesta
        
        System.out.println(palabra4.toUpperCase() + " " + palabra13 + palabra1
        + " " + palabra6 + palabra5 + " " + palabra13.toLowerCase() + palabra1
        + " " + palabra2 + " " + palabra3 + " " + palabra13.toLowerCase() 
        + palabra1 + ". " + palabra11.toUpperCase() + " " + palabra5 + palabra9
        + " " + palabra12 + " " + palabra10 + palabra5 + " " + palabra6 
        + palabra4 + " " + palabra13.toLowerCase() + palabra1 + ", " + palabra7
        + palabra4 + " " + palabra11 + " " + palabra8 + palabra5 + " "
        +palabra4 + palabra13.toLowerCase() + palabra1 + ".");
        
        
        // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        
        //Operadores

        //Operadores aritm�ticos
        /*
        + suma
        - resta
        * multiplicaci�n
        / divisi�n
        % m�dulo o resto de la divisi�n
        Son operadores binarios porque necesitan 2 operandos.
        Los operandos son num�ricos y el resultado es num�rico.
        */
        
        int nro1 = 10;
        int nro2 = 2;
        
        System.out.print("Suma: ");
        System.out.println(nro1 + nro2);
        
        System.out.print("Resta: ");
        System.out.println(nro1 - nro2);
        
        System.out.print("Multiplicaci�n: ");
        System.out.println(nro1 * nro2);
        
        System.out.print("Divisi�n: ");
        System.out.println(nro1 / nro2);
        
        System.out.print("M�dulo o resto de la divisi�n: ");
        System.out.println(nro1 % nro2);
        
        
        //Operadores de asignaci�n
        /*
        = asignaci�n
        += suma y asignaci�n
        -= resta y asignaci�n
        *= multiplicaci�n y asignaci�n
        /= divisi�n y asignaci�n
        %= m�dulo y asignaci�n
        Son operadores binarios.
        Asignan el valor a una variable y se la modifican utilizando una expresi�n.
        */
        
        System.out.println(nro1); //nro1 vale 10
        nro1 = 12; // con el = se le asigna el valor que est� a la derecha (expresi�n)
        System.out.println(nro1); //ahora vale 12
        
        nro1 += 2; // con el += suma 2 y asigna el valor a la variable
        //es lo mismo que hacer: nro1 = nro1 + 2
        System.out.println(nro1); //ahora nro1 vale 14
        
        nro1 -= 2; // con el -= se resta 2 y se asigna el valor a la variable
        //es lo mismo que hacer: nro1 = nro1 - 2
        System.out.println(nro1); //ahora nro1 vale 12
        
        nro1 *= 2; // con el *= se multiplica por 2 y se asigna el valor a la variable
        System.out.println(nro1); //ahora nro1 vale 24
        
        nro1 /= 2; // con el /= se divide por 2 y se asigna el valor a la variable
        System.out.println(nro1); //ahora nro1 vale 12
        
        nro1 %= 2; // con el %= se asigna a la variable el valor del resto de la divisi�n
        //del nro1 con el 2
        System.out.println(nro1); //ahora nro1 vale 0
        
        
        
        
    }

}
