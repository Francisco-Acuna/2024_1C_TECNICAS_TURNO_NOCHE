
package clase06;


public class Clase06 {

    public static void main(String[] args) {
        /*
        Convenciones de escritura
        camel case -> estaEsUnaFraseEnCamelCase (tambi�n se la conoce como
        lower camel case) se utiliza para variables, m�todos y atributos
        pascal case -> EstaEsUnaFraseEnPascalCase (tambi�n se la conoce como
        upper camel case) se utiliza para clases e interfaces
        snake case -> esta_es_una_frase_en_snake_case se utiliza para SQL
        */
        
        System.out.println("** Clase String **");
        //la clase String contiene un vector de caracteres
        
        //podemos crear un objeto de la clase String de varias maneras:
        String texto1 = "Cadena de Texto!";
        String texto2 = new String("hola");
        String texto3 = "hola";
        
        //m�todos para comparar
        //al comparar cadenas de caracteres con el operador ==
        //va a comparar que sean el mismo objeto en memoria
        System.out.println(texto2 == "hola"); //false
        
        //hay una oportunidad en la que la comparaci�n podr�a darnos true
        System.out.println(texto3 == "hola"); //true
        /*
        esto pasa porque existe un comportamiento especial en Java
        denominado "intering". En el cual, las cadenas creadas entre
        comillas dobles se almacenan en un pool de cadenas internas
        para ahorrar memoria. Es decir, que de manera interna, ocupar�an
        el mismo espacio en memotia. Por eso las considera iguales.
        Por lo tanto, comparar contenidos de cadenas con el == no brinda
        un comportamiento garantizado.
        */
        
        //para comparar cadenas de caracteres teniendo en cuenta su contenido
        //.equals() .equalsIgnoreCase()
        System.out.println(texto2.equals("hola")); //true
        //.equals() compara literalmente las cadenas
        System.out.println(texto2.equals("HOLA")); //false
        //.equalsIgnoreCase() ignora las min�sculas y may�sculas
        System.out.println(texto2.equalsIgnoreCase("HOLA")); //true
        
        System.out.println(texto2.equals(texto3));//true
        
        //.contains()
        //devuelve un booleano indicando si contiene la subcadena pasada
        //como par�metro
        System.out.println(texto1.contains("hola")); //false
        System.out.println(texto2.contains("hola")); //true
        System.out.println(texto2.contains(texto3)); //true
        System.out.println(texto1.contains("den")); //true
        
        //.length()
        //devuelve la longitud del vector, es decir, cu�ntos caracteres tiene
        System.out.println(texto1.length()); //16
        System.out.println(texto2.length()); //4
        
        //.isEmpty()
        //indica si la cadena est� vac�a, es decir, si su longitud es igual a cero
        System.out.println(texto1.isEmpty()); //false
        
        //.isBlank() aparece a partir de JDK 11
        //indica si una cadena est� vac�a o en blanco, teniendo en cuenta su 
        //contenido. Es decir si no tiene nada, o solo tiene espacios en blanco
        //o tabulaciones y/o saltos de l�nea
        String texto4 = "    ";
        System.out.println(texto4.isEmpty()); //false
        System.out.println(texto4.isBlank()); //true
        
        //.charAt()
        //devuelve el caracter del �ndice indicado como par�metro
        System.out.println(texto1.charAt(3)); //e
        System.out.println(texto2.charAt(3)); //a
        //System.out.println(texto2.charAt(4)); 
        //la anterior l�nea da error porque no existe el �ndice 4 para 
        //una longitud de 4
        
        
        //.indexOf()
        //devuelve el �ndice de la primera ocurrencia de la subcadena
        //si no encuentra la subcadena, devuelve -1
        System.out.println(texto1.indexOf("texto")); //devuelve -1
        //no lo encontr� porque la T es may�scula en texto1
        System.out.println(texto1.indexOf("Texto")); //10
        
        
        //.trim()
        //quita los espacios de adelante y de atr�s
        System.out.println("   buenas noches   ");
        System.out.println("   buenas noches   ".trim());
        
        
        
        
    }
    
}

