/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase02;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("Hola Mundo!!");
        
        //comentarios
        //un comentario es un texto adicional que agregamos
        //a nuestro c�digo para explicar su funcionalidad
        
        //esto es un comentario en l�nea
        
        /*
        Esto es un bloque 
        de comentarios.
        Podemos escribir 
        en varias l�neas
        */
        
        /**
         * Esto es un comentario de JavaDoc
         * Podemos escribir en varias l�neas
         * Se utiliza para documentar
         * va antes de definiciones de m�todos, clases, etc.
         */
        
        //sout + tab atajo de teclado para imprimir por consola
        System.out.println("Hello World!"); //esto es una sentencia 
        //una sentencia es una orden que se le da al programa
        //para realizar una tarea espec�fica
        //las sentencias siempre terminan con ;
        //el ; separa una sentencia de otra
        
        //impresi�n con salto de l�nea
        System.out.println("1");
        System.out.println("2");
        System.out.println("3");
        System.out.println("4");
        System.out.println("5");
        
        //impresi�n sin salto de l�nea
        System.out.print("1");
        System.out.print("2");
        System.out.print("3");
        System.out.print("4");
        System.out.print("5");
        
        System.out.println("");
        
        //Variables
        
        /*
        Una variable es un nombre que se asocia con una porci�n de la 
        memoria del ordenador, en donde se almacena el valor asignado
        a esa variable.
        Las variables deben declararse antes de usarlas.
        La declaraci�n es una sentencia en la que figura el tipo de dato
        y el nombre que le asignamos a la variable.
        */
        
        int a; // declaraci�n de variable con su tipo de dato y nombre
        a = 2; //asignaci�n de valor a la variable
        int b=3; //declaraci�n y asignaci�n en una misma l�nea
        
        a = 4; //cambiar el valor de una variable
//        a = "Hola"; ERROR, no se puede asignar otro tipo de dato
//        char a; ERROR, la variable ya fue declarada, no se puede volver a declarar

        //Una variable puede tener una �nica declaraci�n
        //y puede tener innumerables valores.
        
    }
    
}

