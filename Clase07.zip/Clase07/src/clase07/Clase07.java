
package clase07;

import java.util.Scanner;


public class Clase07 {

    public static void main(String[] args) {
        /*
        Convenciones de escritura
        camel case -> estaEsUnaFraseEnCamelCase (tambi�n se la conoce como
        lower camel case) se utiliza para variables, m�todos y atributos
        pascal case -> EstaEsUnaFraseEnPascalCase (tambi�n se la conoce como
        upper camel case) se utiliza para clases e interfaces
        snake case -> esta_es_una_frase_en_snake_case se utiliza para SQL
        */
        
        System.out.println("** Clase String **");
        //la clase String contiene un vector de caracteres
        
        //podemos crear un objeto de la clase String de varias maneras:
        String texto1 = "Cadena de Texto!";
        String texto2 = new String("hola");
        String texto3 = "hola";
        
        //m�todos para comparar
        //al comparar cadenas de caracteres con el operador ==
        //va a comparar que sean el mismo objeto en memoria
        System.out.println(texto2 == "hola"); //false
        
        //hay una oportunidad en la que la comparaci�n podr�a darnos true
        System.out.println(texto3 == "hola"); //true
        /*
        esto pasa porque existe un comportamiento especial en Java
        denominado "intering". En el cual, las cadenas creadas entre
        comillas dobles se almacenan en un pool de cadenas internas
        para ahorrar memoria. Es decir, que de manera interna, ocupar�an
        el mismo espacio en memotia. Por eso las considera iguales.
        Por lo tanto, comparar contenidos de cadenas con el == no brinda
        un comportamiento garantizado.
        */
        
        //para comparar cadenas de caracteres teniendo en cuenta su contenido
        //.equals() .equalsIgnoreCase()
        System.out.println(texto2.equals("hola")); //true
        //.equals() compara literalmente las cadenas
        System.out.println(texto2.equals("HOLA")); //false
        //.equalsIgnoreCase() ignora las min�sculas y may�sculas
        System.out.println(texto2.equalsIgnoreCase("HOLA")); //true
        
        System.out.println(texto2.equals(texto3));//true
        
        //.contains()
        //devuelve un booleano indicando si contiene la subcadena pasada
        //como par�metro
        System.out.println(texto1.contains("hola")); //false
        System.out.println(texto2.contains("hola")); //true
        System.out.println(texto2.contains(texto3)); //true
        System.out.println(texto1.contains("den")); //true
        
        //.length()
        //devuelve la longitud del vector, es decir, cu�ntos caracteres tiene
        System.out.println(texto1.length()); //16
        System.out.println(texto2.length()); //4
        
        //.isEmpty()
        //indica si la cadena est� vac�a, es decir, si su longitud es igual a cero
        System.out.println(texto1.isEmpty()); //false
        
        
        //.isBlank() aparece a partir de JDK 11
        //indica si una cadena est� vac�a o en blanco, teniendo en cuenta su 
        //contenido. Es decir si no tiene nada, o solo tiene espacios en blanco
        //o tabulaciones y/o saltos de l�nea
        String texto4 = "    ";
        System.out.println(texto4.isEmpty()); //false
        System.out.println(texto4.isBlank()); //true
        
        //.charAt()
        //devuelve el caracter del �ndice indicado como par�metro
        System.out.println(texto1.charAt(3)); //e
        System.out.println(texto2.charAt(3)); //a
        //System.out.println(texto2.charAt(4)); 
        //la anterior l�nea da error porque no existe el �ndice 4 para 
        //una longitud de 4
        
        
        //.indexOf()
        //devuelve el �ndice de la primera ocurrencia de la subcadena
        //si no encuentra la subcadena, devuelve -1
        System.out.println(texto1.indexOf("texto")); //devuelve -1
        //no lo encontr� porque la T es may�scula en texto1
        System.out.println(texto1.indexOf("Texto")); //10
        
        
        //.trim()
        //quita los espacios de adelante y de atr�s
        System.out.println("   buenas noches   ");
        System.out.println("   buenas noches   ".trim());
        
        //.startsWith() .endsWith()
        //devuelve un booleano indicando si la cadena comienza o finaliza
        //con la subcadena pasada como par�metro
        System.out.println(texto1.startsWith("hola")); //false
        System.out.println(texto2.startsWith("hola")); //true
        System.out.println(texto1.endsWith("exto")); //false
        System.out.println(texto1.endsWith("exto!")); //true
        
        
        //m�todos replace()
        //reemplazar un caracter por otro
        System.out.println(texto1.replace('e', 'i'));
        //reemplazar una cadena de caracteres por otra
        System.out.println(texto1.replace("Texto", "caracteres"));
        //reemplazar solo la primera vez que aparezca la subcadena
        texto4 = "manzana, manzana, naranja";
        System.out.println(texto4.replaceFirst("manzana", "banana"));
        //reemplazar todas las veces que aparezca la subcadena
        System.out.println(texto4.replaceAll("manzana", "banana"));
        /*
        si bien el m�todo replace() tambi�n reemplaza todas las veces que aparezca
        la subcadena, el m�todo replaceAll() es mucho m�s potente. Permite buscar
        y reemplazar patrones de expresiones regulares.
        Una expresi�n regular es una secuencia de caracteres que definen un patr�n
        espec�fico.
        */
        
        String texto5 = "Mi n�mero es 011-8888-9999 y mi otro n�mero es 365-1010-2727";
        
        System.out.println(texto5.replaceAll("\\d{3}-\\d{4}-\\d{4}", "[hidden information]"));
        
        //.repeat()
        //repite la cadena la cantidad de veces que le indiquemos como par�metro
        System.out.println(texto2.repeat(3));
        
        //.substring()
        //se utiliza para devolver una subcadena
        //si se llama con un solo par�metro, devuelve la subcadena a partir del
        //�ndice pasado en el par�metro
        System.out.println(texto1.substring(5));
        //si se utilizan 2 par�metros, va a retornar una subcadena desde la 
        //posici�n que indique el primer par�metro y hasta antes de la posici�n
        //que se indique como segundo par�metro.
        System.out.println(texto1.substring(3, 12));
        
        //anteriormente hemos estudiado los m�todos
        //.toLowerCase() .toUpperCase()
        
        //caracteres de escape
        /*
        los caracteres de escape son secuencias especiales de caracteres que se 
        utilizan en cadenas de texto y literales de caracteres, para representar
        caracteres especiales o caracteres que no se puede representar directamente.
        Los caracteres de escape comienzan con una barra invertida \ seguida del
        caracter que indica qu� tipo de escape se est� utilizando.
        */
        
        //algunos ejemplos:
        
        // \n salto de l�nea
        System.out.println("Hola\nMundo!");
        
        // \t tabulaci�n
        System.out.println("Hola\tMundo!");
        
        // \" comillas dobles
        System.out.println("\"Hola Mundo!\"");
        
        // \' comillas simples
        System.out.println("\'Hola Mundo!\'");
        
        // \\ barra invertida o contrabarra
        System.out.println("\\Hola Mundo!\\");
        
        System.out.println("\n************************************\n");
        
        System.out.println("** Clase System **");
        
        /*
        La clase System es un intermediario entre la m�quina virtual de Java
        y el entorno de ejecuci�n en el que estamos ejecutando nuestro programa.
        Como la m�quina virtual de Java puede ejecutarse en m�ltiples plataformas,
        la clase System nos abstae de la plataforma sobre la que se est� ejecutando.
        */
        
        //Los atributos m�s cl�sicos son out, err, in
        //representan stream de entrada y salida
        //son atributos finales y est�ticos
        //out es un stream de salida sincronizado
        //err es un stream de salida desincronizado
        
        /*
        "stream" (flujo o corriente), es una secuencia de datos que se procesa
        o transmite de manera secuencial, en lugar de cargarse o procesarse en 
        su totalidad antes de utilizarse.
        */
        
        //el atributo out es sincronizado, imprime seg�n la secuencia ordenada
        System.out.println("Hola 1");
        System.out.println("Hola 2");
        System.out.println("Hola 3");
        System.out.println("Hola 4");
        System.out.println("Hola 5");
        System.out.println("Hola 6");
        System.out.println("Hola 7");
        System.out.println("Hola 8");
        System.out.println("Hola 9");
        System.out.println("Hola 10");
        System.out.println("Hola 11");
        System.out.println("Hola 12");
        System.out.println("Hola 13");
        System.out.println("Hola 14");
        System.out.println("Hola 15");
        System.out.println("Hola 16");
        System.out.println("Hola 17");
        System.out.println("Hola 18");
        System.out.println("Hola 19");
        System.out.println("Hola 20");
        
        System.err.println("OCURRI� UN ERROR !");
        /*
        El atributo err es desincronizado. Cuando la m�quina lleg� hasta ac�
        le dio la orden a la consola de imprimir todo lo anterior. Como el 
        procesador es mucho m�s r�pido que el video, cuando la m�quina llega
        hasta la �ltima instrucci�n del "hola", a�n se est� imprimiendo, porque
        las dem�s impresiones entraron en una cola de trabajo. Al econtrar al
        err se interrumpe la cola de trabajo y se imprime lo del err porque es
        desincronizado. Puede aparecer en cualquier lugar.
        */
        
        //.exit()
        //el m�todo .exit() cierra el runtime, es decir, que finaliza el programa
//        System.out.println("Ejecuto el m�todo exit()");
//        System.exit(0);
//        System.out.println("Esta sentencia no se ejecuta");
        //el par�metro 0 indica que no hubo error al finalizar el programa
        //el par�metro 1 indica que si hubo error al finalizar el programa
        //el par�metro -1 indica que el programa finaliz� con advertencias.

        //diccionario getenv()
        //este m�todo devuelve un diccionario de propiedades del entorno de
        //ejecuci�n, es decir, propiedades del sistema. Que var�an seg�n el
        //SO y versi�n de Java.
        System.out.println("getenv()");
        System.out.println(System.getenv());
        
        //el getProperties() representa un mapa o vector asociativo que es igual
        //en todas las configuraciones.
        System.out.println(System.getProperties()); // propiedades del sistema
        System.out.println(System.getProperty("os.name")); //nombre del SO
        System.out.println(System.getProperty("os.version")); //versi�n del SO
        System.out.println(System.getProperty("os.arch")); //arquitectura
        System.out.println(System.getProperty("java.version")); //versi�n de Java
        System.out.println(System.getProperty("user.name")); //nombre del usuario del SO
        System.out.println(System.getProperty("user.home")); //directorio del usuario

        //El atributo in representa un stream de entrada y es sincronizado
        //permite ingresar datos desde la terminal del sistema
        //por ejemplo, utilizando la clase Scanner
        
        System.out.println("** Clase Scanner **");
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Ingrese su nombre:");
        String nombre = teclado.next();
        System.out.println("Su nombre es " + nombre);
        
        
    }
    
}

