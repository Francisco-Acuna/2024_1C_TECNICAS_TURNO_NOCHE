/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase03;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int c=12, d=32, e=41; //declaraci�n y asignaci�n m�ltiple en l�nea
        
        //Tipos de datos primitivos
        
        //byte - ocupa 1 byte y representa un n�mero entero de entre -128 y 127
        byte f = 100;
        System.out.println(f); //imprimo el valor de la variable
        
        //short - ocupa 2 bytes y representa un n�mero entero de entre
        //-32.768 y 32.767
        short g = 32000; //no separamos los miles con punto. Va todo junto.
        System.out.println(g);
        
        //int - ocupa 4 bytes y representa un n�mero entero de entre
        //-2.147.483.648 y 2.147.483.647
        int h = 2135698745; //es el tipo de dato num�rico entero m�s utilizado
        System.out.println(h); 
        
        //long - ocupa 8 bytes y representa un valor muy grande
        long i = 23541356845324L; //debe llevar un L al final del valor asignado
        //por convenci�n se utiliza la L may�scula
        System.out.println(i);
        
        //float - ocupa 4 bytes y tiene una precisi�n de 32 bits
        float j = 14.25f; //debe llevar una f al final del valor asignado
        //el punto separa los decimales, no utilizamos la coma
        System.out.println(j);
        
        //double - ocupa 8 bytes y tiene una precisi�n de 64 bits
        double k = 23.45; //no hace falta agregarle ninguna letra
        System.out.println(k);
        
        //diferencia entre float y double
        float fl = 10f;
        double dl = 10;
        System.out.println(fl / 3);
        System.out.println(dl / 3);
        
        //boolean - ocupa 1 byte y almacena s�lo 2 valores (0 y 1)
        //est�n representados por los valores true y false
        boolean l = true;
        boolean m = false;
        System.out.println(l);
        System.out.println(m);
        
        //char - ocupa 2 bytes y almacena un entero que representa 
        //un caracter de la tabla unicode
        //unicode es un est�ndar de codificaci�n de caracteres a nivel mundial
        char n = 65; //se almacena como un entero, pero representa un caracter
        System.out.println(n);
        //entre una may�scula y una min�scula hay 32 n�meros
        n += 32; 
        System.out.println(n);
        //tambi�n se puede almacenar la variable con el caracter directamente
        n = 'f';// el caracter se representa entre comillas simples
        System.out.println(n);
        
        //String - NO ES UN TIPO DE DATO PRIMITIVO, ES UNA CLASE
        //representa una cadena de caracteres
        String o = "Hola";
        String p = "Hola, soy una cadena de caracteres!";
        //al ser una clase, el tipo de dato comienza con may�scula
        //el valor asignado debe ir entre comillas dobles ""
        System.out.println(o);
        System.out.println(p);
        
        //algunos m�todos de la clase String
        
        //toLowerCase()
        //pasa la cadena a min�sculas
        System.out.println(o.toLowerCase());
        
        //toUpperCase()
        //pasa la cadena a may�sculas
        System.out.println(p.toUpperCase());
        
        //Constantes
        //son similares a las variables, pero la diferencia es que no pueden
        //cambiar su valor
        final double PI = 3.14;
        //para declarar constantes debemos utilizar la palabra reservada final
        //por convenci�n el nombre de las constantes va todo en may�scula
//        PI = 3.15; ERROR, no puedo modificar su valor
        

        //Concatenaci�n
        String nombre = "Marcelo";
        String apellido = "L�pez";
        System.out.println(nombre); 
        System.out.println("Su nombre es: " + nombre);
        System.out.println("El nombre es: " + nombre + " y el apellido es: " + apellido);

        
    }
    
}
